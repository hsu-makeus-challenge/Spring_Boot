package umc.spring.domain;

public enum TandF {
    T,
    F;
}
